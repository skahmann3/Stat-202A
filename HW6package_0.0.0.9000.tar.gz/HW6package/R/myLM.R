#' A Linear Regression Function
#'
#' This function allows you to run a linear regression using QR decomposition.
#' @param X an n x p matrix of explanatory variables
#' @param Y is an n dimensional vector of responses
#' @param intercept T/F you want to include an intercept in the regression
#' @keywords simple linear regression
#' @export
#' @examples
#' X <- matrix(rnorm(100), 50, 2)
#' Y <- matrix(3 * X[,1] + 2 * X[,2] + rnorm(50))
#' myLM(X,Y)
#' myLM()


myLM <- function(X, Y, intercept=TRUE){

  ## Perform the linear regression of Y on X
  ## Input:
  ## X is an n x p matrix of explanatory variables
  ## Y is an n dimensional vector of responses

  if(intercept == TRUE){

    n <- nrow(X)
    p <- ncol(X)

    ## Stack (X, Y) and solve it by QR decomposition
    Z <- cbind(rep(1,n), X, Y)
    R <- myQR(Z)$R

    R1 <- R[1:(p + 1), 1:(p + 1)]
    Y1 <- R[1:(p + 1), p + 2]
    Y2 <- R[(p+2):n, p+2]

    beta_ls <- solve(R1) %*% Y1


    newX <- cbind(rep(1,n),X)
    RSS <- sum(Y2^2)

    errors <- sqrt(diag(RSS/(n-p-1) * solve(t(newX)%*%newX)))

  }

  else{

    n <- nrow(X)
    p <- ncol(X)

    ## Stack (X, Y) and solve it by QR decomposition
    Z <- cbind(X, Y)
    R <- myQR(Z)$R

    R1 <- R[1:(p + 0), 1:(p + 0)]
    Y1 <- R[1:(p + 0), p + 1]

    beta_ls <- solve(R1) %*% Y1

    Y2 <- R[(p+1):n, p+1]

    RSS <- sum(Y2^2)

    errors <- sqrt(diag(RSS/(n-p-1) * solve(t(X)%*%X)))

  }

  ## Function returns the 1 x (p + 1) vector beta_ls,
  ## the least squares solution vector
  ## the error
  output=list(beta_ls, errors)

  return(output)

}
