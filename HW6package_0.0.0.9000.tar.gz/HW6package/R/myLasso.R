#' A Lasso Regression  Function
#'
#' Find the lasso solution path for various values of the regularization parameter lambda.
#' @param X an n x p matrix of explanatory variables.
#' @param Y n dimensional response vector
#' @param lambda_all Vector of regularization parameters. Make sure to sort lambda_all in decreasing order for efficiency.
#' @keywords lasso regression
#' @export
#' @examples
#' Y <- mtcars[,1]
#' X <- mtcars[,-1]
#' lambda_all = (5:1)*10
#' myLasso(X,Y,lambda_all)
#' myLasso()


myLasso <- function(X, Y, lambda_all){

  # Find the lasso solution path for various values of
  # the regularization parameter lambda.
  #
  # X: n x p matrix of explanatory variables.
  # Y: n dimensional response vector
  # lambda_all: Vector of regularization parameters. Make sure
  # to sort lambda_all in decreasing order for efficiency.
  #
  # Returns a matrix containing the lasso solution vector
  # beta for each regularization parameter.

  #######################
  ## FILL IN CODE HERE ##
  #######################

  L=length(lambda_all)
  lambda_all=sort(lambda_all, decreasing=TRUE)

  n=dim(X)[1]
  p=dim(X)[2]

  X <- cbind(rep(1, n), X)

  R=Y
  SS=rep(0,p+1)
  int=rep(0,L)
  beta=rep(0,p+1)
  beta_all=matrix(nrow=p+1, ncol=L)
  Tt=100

  for(j in 1:(p+1))
    SS[j]=sum(X[,j]^2)

  for(l in 1:L)
  {
    lambda=lambda_all[l]
    for(t in 1:Tt){

      k=1
      db=sum(R*X[,k])/SS[k]
      b=beta[k]+db
      # b=sign(b)*max(0, abs(b)-lambda/SS[k])
      db=b-beta[k]
      R=R-X[,k]*db
      beta[k]=b


      for(k in 2:(p+1)){
        db=sum(R*X[,k])/SS[k]
        b=beta[k]+db
        b=sign(b)*max(0, abs(b)-lambda/SS[k])
        db=b-beta[k]
        R=R-X[,k]*db
        beta[k]=b
      }
    }

    beta_all[,l]=beta

  }

  ## Function should output the matrix beta_all, the
  ## solution to the lasso regression problem for all
  ## the regularization parameters.
  ## beta_all is (p+1) x length(lambda_all)
  return(beta_all)

}
