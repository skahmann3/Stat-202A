#' A PCA Function
#'
#' This function allows you to express you to conduct Principal Components Analysis.
#' @param A  Square matrix
#' @param numIter Number of iterations
#' @keywords principal components analysis
#' @export
#' @examples
#' n <- 100
#' p <- 3
#' X <- matrix(rnorm(n * p), nrow = 100)
#' A <- t(X) %*% X
#' myEigen_QR(A)
#' myEigen_QR()


myEigen_QR <- function(A, numIter = 1000){

  ## Perform PCA on matrix A using your QR function, myQRC.
  ## Input:
  ## A: Square matrix
  ## numIter: Number of iterations

  r <- nrow(A)
  c <- ncol(A)
  V <- matrix(runif(r * r), r, r)

  for(i in 1:numIter){
    Q <- myQR(V)$Q
    V <- A %*% Q
  }

  eigen_out <- myQR(V)
  Q <- eigen_out$Q
  R <- eigen_out$R

  ## Function should output a list with D and V
  ## D is a vector of eigenvalues of A
  ## V is the matrix of eigenvectors of A (in the
  ## same order as the eigenvalues in D.)
  return(list("D" = diag(R), "V" = Q))

}
