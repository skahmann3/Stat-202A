#' A Logistic Regression Function
#'
#' This function allows you run a logistic regression using QR decomposition.
#' @param X an n x p matrix of explanatory variables
#' @param Y an n dimensional vector of binary responses
#' @keywords logistic regression binary
#' @export
#' @examples
#' n <- 50
#' p <- 4
#' X    <- matrix(rnorm(n * p), nrow = n)
#' beta <- c(12, -2,-3, 4)
#' Y    <- 1 * (runif(n) < expit(X %*% beta))
#' myLogistic(X, Y)
#' myLogistic()


myLogistic <- function(X, Y){

  ########################
  ## FILL IN CODE BELOW ##
  ########################

  n <- nrow(X)
  p <- ncol(X)

  beta    <- rep(0, p)
  epsilon <- 1e-6

  numIter <- 1
  pr=c(rep(0,n))
  while(TRUE && numIter < 100){
    eta <- X %*% beta
    pr  <- expit(eta)
    w   <- pr * (1 - pr)
    z   <- eta + (Y - pr) / w
    sw  <- sqrt(w)
    mw=rep(sw,p)

    x_work <- mw * X
    y_work <- sw * z

    beta_new <- myLM(x_work, y_work, intercept = FALSE)[[1]]
    err      <- sum(abs(beta_new - beta))
    beta     <- beta_new
    if(err < epsilon)
      break
    numIter <- numIter + 1
  }

  beta

  w=pr*(1-pr)

  errors = sqrt(diag(solve(t(X) %*% diag(c(w)) %*% X)))

  output=list(beta, errors)

}

