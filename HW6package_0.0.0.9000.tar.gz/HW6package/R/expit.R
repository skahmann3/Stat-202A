#' A Sigmoid Function
#'
#' This function allows you to compute the sigmoid of x.
#' @param x a numeric vector
#' @keywords sigmoid
#' @export
#' @examples
#' x <- 1:5
#' expit(x)
#' expit()


expit <- function(x){
  1 / (1 + exp(-x))
}
