#' A Ridge Regression  Function
#'
#' This function performs ridge regression of Y on X.
#' @param X an n x p matrix of explanatory variables.
#' @param Y an n vector of dependent variables, can also be a matrix
#' @param lambda regularization parameter (lambda >= 0)
#' @keywords ridge regression
#' @export
#' @examples
#' n = 20
#' p = 10
#' sigma = .1
#' x = runif(n)
#' x=sort(x)
#' Y = x^2 + rnorm(n)*sigma
#' myRidge(x,Y, lambda=0)
#' myRidge()

myRidge <- function(X, Y, lambda){

  # Perform ridge regression of Y on X.
  #
  # X: an n x p matrix of explanatory variables.
  # Y: an n vector of dependent variables. Y can also be a
  # matrix, as long as the function works.
  # lambda: regularization parameter (lambda >= 0)
  # Returns beta, the ridge regression solution.

  ##################################
  ## FILL IN THIS SECTION OF CODE ##
  ##################################

  n <- dim(X)[1]
  p <- dim(X)[2]

  ## Define cross product matrix
  Z <- cbind(rep(1, n), X, Y)
  A <- t(Z) %*% Z

  ## Add ridge to cross product matrix
  D <- diag(rep(lambda, p + 2))
  D[p + 2, p + 2] <- 0

  ## Don't regularize intercept
  D[1, 1] <- 0
  A <- A + D
  S <- mySweep(A, p + 1)
  beta_ridge <- S[1:(p + 1), p + 2]

  ## Function should output the vector beta_ridge, the
  ## solution to the ridge regression problem. beta_ridge
  ## should have p + 1 elements.
  return(beta_ridge)

}
